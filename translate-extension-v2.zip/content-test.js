// 最简单的测试脚本
console.log('===========================================');
console.log('TEST: content-test.js 已加载！');
console.log('TEST: 当前时间:', new Date().toISOString());
console.log('TEST: 页面URL:', window.location.href);
console.log('===========================================');

alert('翻译插件测试版本已加载！');
